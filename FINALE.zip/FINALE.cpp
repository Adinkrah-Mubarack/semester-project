#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

class Contact {
public:
    Contact(const std::string& name, const std::string& phoneNumber)
        : name(name), phoneNumber(phoneNumber) {}

    const std::string& getName() const {
        return name;
    }

    const std::string& getPhoneNumber() const {
        return phoneNumber;
    }

private:
    std::string name;
    std::string phoneNumber;
};

class Phonebook {
public:
    void addContact(const Contact& contact) {
        contacts.push_back(contact);
    }

    void displayContacts() const {
        std::cout << "Contacts:\n";
        for (size_t i = 0; i < contacts.size(); ++i) {
            const Contact& contact = contacts[i];
            std::cout << "Name: " << contact.getName() << "\n";
            std::cout << "Phone Number: " << contact.getPhoneNumber() << "\n";
            std::cout << "-------------------\n";
        }
    }

    void searchContact(const std::string& name) const {
        bool found = false;
        for (size_t i = 0; i < contacts.size(); ++i) {
            const Contact& contact = contacts[i];
            if (contact.getName() == name) {
                std::cout << "Contact found:\n";
                std::cout << "Name: " << contact.getName() << "\n";
                std::cout << "Phone Number: " << contact.getPhoneNumber() << "\n";
                found = true;
                break;
            }
        }
        if (!found) {
            std::cout << "Contact not found.\n";
        }
    }

    void sortContactsByName() {
        std::sort(contacts.begin(), contacts.end(), CompareContactsByName());
    }

    void saveContactsToFile(const std::string& filename) {
        std::ofstream outFile(filename.c_str());
        if (outFile.is_open()) {
            for (size_t i = 0; i < contacts.size(); ++i) {
                const Contact& contact = contacts[i];
                outFile << contact.getName() << "," << contact.getPhoneNumber() << "\n";
            }
            outFile.close();
            std::cout << "Contacts saved to " << filename << ".\n";
        } else {
            std::cout << "Error opening file for writing.\n";
        }
    }

    void loadContactsFromFile(const std::string& filename) {
        contacts.clear();
        std::ifstream inFile(filename.c_str());
        if (inFile.is_open()) {
            std::string line;
            while (std::getline(inFile, line)) {
                size_t commaPos = line.find(",");
                if (commaPos != std::string::npos) {
                    std::string name = line.substr(0, commaPos);
                    std::string phoneNumber = line.substr(commaPos + 1);
                    contacts.push_back(Contact(name, phoneNumber));
                }
            }
            inFile.close();
            std::cout << "Contacts loaded from " << filename << ".\n";
        } else {
            std::cout << "Error opening file for reading.\n";
        }
    }

private:
    struct CompareContactsByName {
        bool operator()(const Contact& lhs, const Contact& rhs) const {
            return lhs.getName() < rhs.getName();
        }
    };

    std::vector<Contact> contacts;
};

int main() {
    Phonebook phonebook;

    phonebook.addContact(Contact("John ", "0509886342"));
    phonebook.addContact(Contact("Jane ", "0578642213"));
    phonebook.addContact(Contact("Alice ", "0246788901"));

    int choice;
    do {
        std::cout << "Phonebook Application\n";
        std::cout << "1. Display Contacts\n";
        std::cout << "2. Search Contact\n";
        std::cout << "3. Sort Contacts by Name\n";
        std::cout << "4. Save Contacts to File\n";
        std::cout << "5. Load Contacts from File\n";
        std::cout << "6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                phonebook.displayContacts();
                break;
            case 2: {
                std::string searchName;
                std::cout << "Enter name to search: ";
                std::cin.ignore();
                std::getline(std::cin, searchName);
                phonebook.searchContact(searchName);
                break;
            }
            case 3:
                phonebook.sortContactsByName();
                std::cout << "Contacts sorted by name.\n";
                break;
            case 4: {
                std::string filename;
                std::cout << "Enter filename to save contacts: ";
                std::cin >> filename;
                phonebook.saveContactsToFile(filename);
                break;
            }
            case 5: {
                std::string filename;
                std::cout << "Enter filename to load contacts from: ";
                std::cin >> filename;
                phonebook.loadContactsFromFile(filename);
                break;
            }
            case 6:
                std::cout << "Exiting...\n";
                break;
            default:
                std::cout << "Invalid choice\n";
                break;
        }
    } while (choice != 6);

    return 0;
}

